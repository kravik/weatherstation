from flask import Flask
from flask.ext.restful import Api
from resources import MeasurementListAPI, MeasurementAPI, MeasurementStatisticAPI

app = Flask(__name__)
api = Api(app)

api.add_resource(MeasurementListAPI, '/measurements', endpoint='measurements')
api.add_resource(MeasurementAPI, '/measurements/<string:item_id>', endpoint='measurement')
api.add_resource(MeasurementStatisticAPI, '/stats', endpoint='stats')

if __name__ == '__main__':
    app.run(debug=True)
