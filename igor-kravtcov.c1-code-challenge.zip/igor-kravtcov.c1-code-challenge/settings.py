#Extend list of valid metrics here if new instrument was installed

UNITS = ['temperature', 'dewPoint', 'precipitation']
