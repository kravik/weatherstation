import pytz
from datetime import datetime, timedelta

from flask.ext.restful import Resource, reqparse, fields, marshal, abort
from flask.ext.restful.inputs import datetime_from_iso8601

from settings import UNITS
from models import Measurement, Metric, MetricStat


class MeasurementBaseAPI(Resource):
    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('timestamp', type=str,
                                   required=True,
                                   help='timestamp is required field',
                                   location='json')
        self.response_fields = {
            'timestamp': fields.String,
        }

        for unit in UNITS:
            self.reqparse.add_argument(unit, type=float, location='json')
            self.response_fields[unit] = fields.Float(attribute='metrics.{}.value'.format(unit))
        super(MeasurementBaseAPI, self).__init__()

    def _get_item_or_abort(self, item_id, verify_item_id=None):
        if not Measurement.objects.exists(item_id):
            abort(404, message="Item {} doesn't exist".format(item_id))
        if verify_item_id and item_id != verify_item_id:
            abort(409)


class MeasurementListAPI(MeasurementBaseAPI):

    def post(self):
        args = self.reqparse.parse_args()
        try:
            args['datetime'] = datetime_from_iso8601(args['timestamp'])
        except ValueError:
            abort(400, message="timestamp should be in ISO 8601 format")
        m = Measurement.objects.create(args)
        return {}, 201, {'Location': '/measurements/{}'.format(m.id)}


class MeasurementAPI(MeasurementBaseAPI):

    def _get_single(self, item_id):
        self._get_item_or_abort(item_id)
        item = Measurement.objects.get(item_id)
        return marshal(item, self.response_fields)

    def _find_list(self, start_date, end_date):
        items = Measurement.objects.find(
            lambda x: x.datetime >= start_date and x.datetime < end_date)
        if len(items) == 0:
            abort(404, message="No mesurements for your request")
        return [marshal(v, self.response_fields) for v in items]

    def get(self, item_id):
        try:
            # return list of measurement for the day
            start_date = pytz.utc.localize(datetime.strptime(item_id, '%Y-%m-%d'))
            end_date = start_date + timedelta(days=1)
            return self._find_list(start_date, end_date)
        except ValueError:
            # return single measurement by primary key
            return self._get_single(item_id)

    def put(self, item_id):
        args = self.reqparse.parse_args()
        self._get_item_or_abort(item_id, verify_item_id=args['timestamp'])
        item = Measurement.objects.update(item_id, args, partial=False)
        return marshal(item, self.response_fields), 204

    def patch(self, item_id):
        args = self.reqparse.parse_args()
        self._get_item_or_abort(item_id, verify_item_id=args['timestamp'])
        item = Measurement.objects.update(item_id, args, partial=True)
        return marshal(item, self.response_fields), 204

    def delete(self, item_id):
        self._get_item_or_abort(item_id)
        Measurement.objects.delete(item_id)
        return {}, 204


class MeasurementStatisticAPI(Resource):
    valid_stats = {'min', 'max', 'average'}

    def __init__(self):
        self.reqparse = reqparse.RequestParser()
        self.reqparse.add_argument('fromDateTime', type=str,
                                   required=True,
                                   help='fromDateTime is required field',
                                   location='args')
        self.reqparse.add_argument('toDateTime', type=str,
                                   required=True,
                                   help='toDateTime is required field',
                                   location='args')
        self.reqparse.add_argument('stat', type=str,
                                   required=True, action='append',
                                   help='stat is required field',
                                   location='args')
        self.reqparse.add_argument('metric', type=str,
                                   required=True, action='append',
                                   help='metric is required field',
                                   location='args')
        self.response_fields = {
            'metric': fields.String,
            'stat': fields.String,
            'value': fields.Float,
        }
        super(MeasurementStatisticAPI, self).__init__()

    def validate_args_or_abort(self):
        args = self.reqparse.parse_args()
        try:
            self.start_date = datetime_from_iso8601(args['fromDateTime'])
            self.end_date = datetime_from_iso8601(args['toDateTime'])
        except ValueError:
            abort(400, message='Incorrect date format.')
        self.metrics = set(args['metric']) & set(UNITS)
        self.stats = set(args['stat']) & self.valid_stats
        if len(self.metrics) == 0:
            abort(400, message='No metric provided.')
        if len(self.stats) == 0:
            abort(400, message='No stat provided.')

    def get(self):
        self.validate_args_or_abort()
        agg_result = Measurement.objects.aggregate(
            lambda x: x.datetime >= self.start_date and x.datetime < self.end_date, self.metrics)
        result = []
        for k, v in agg_result.iteritems():
            for stat in self.stats:
                item = MetricStat(k, stat, v[stat] if stat != 'average' else v[stat]['v'])
                result.append(marshal(item, self.response_fields))
        return result
