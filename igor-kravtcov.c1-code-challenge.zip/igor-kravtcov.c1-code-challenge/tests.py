import os
from app import app
import unittest
import json
from models import Measurement


class JSONTestCase(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        self.app = app.test_client()
        Measurement.objects.invalidate()

    def post_json(self, url, data):
        return self.app.post(
            url,
            data=json.dumps(data),
            content_type='application/json'
        )

    def get_json(self, url):
        return self.app.get(
            url,
            content_type='application/json'
        )

    def put_json(self, url, data):
        return self.app.put(
            url,
            data=json.dumps(data),
            content_type='application/json'
        )

    def patch_json(self, url, data):
        return self.app.patch(
            url,
            data=json.dumps(data),
            content_type='application/json'
        )

    def delete_json(self, url):
        return self.app.delete(
            url,
            content_type='application/json'
        )


class CreateMesurementTestCase(JSONTestCase):

    def test_create_valid(self):
        timestamp = '2015-09-01T16:00:00.000Z'
        exp_location = '/measurements/{}'.format(timestamp)
        response = self.post_json(
            '/measurements',
            dict(
                timestamp=timestamp,
                temperature=27.1,
                dewPoint=16.7,
                precipitation=0
            )
        )
        index = response.headers['Location'].find(exp_location)
        self.assertEqual(response.status_code, 201)
        self.assertNotEqual(index, -1)

    def test_create_invalid(self):
        data = [
            dict(
                timestamp='2015-09-01T16:00:00.000Z',
                temperature="not a number",
                dewPoint=16.7,
                precipitation=0),
            dict(
                timestamp='2015-09-01T16:00:00.000Z',
                temperature=23.3,
                dewPoint="not a number",
                precipitation=0),
            dict(
                timestamp='2015-09-01T16:00:00.000Z',
                temperature=23.3,
                dewPoint=17.1,
                precipitation="not a number"),
            dict(
                temperature=23.3,
                dewPoint=16.7,
                precipitation=0),
        ]
        for item in data:
            response = self.post_json(
                '/measurements',
                item
            )
            self.assertEqual(response.status_code, 400)


class GetMesurementTestCase(JSONTestCase):
    def setUp(self):
        super(GetMesurementTestCase, self).setUp()
        data = [
            dict(
                timestamp='2015-09-01T16:00:00.000Z',
                temperature=27.1,
                dewPoint=16.7,
                precipitation=0),
            dict(
                timestamp='2015-09-01T16:10:00.000Z',
                temperature=27.3,
                dewPoint=16.9,
                precipitation=0),
            dict(
                timestamp='2015-09-01T16:20:00.000Z',
                temperature=27.5,
                dewPoint=17.1,
                precipitation=0),
            dict(
                timestamp='2015-09-01T16:30:00.000Z',
                temperature=27.4,
                dewPoint=17.3,
                precipitation=0),
            dict(
                timestamp='2015-09-01T16:40:00.000Z',
                temperature=27.2,
                dewPoint=17.2,
                precipitation=0),
            dict(
                timestamp='2015-09-02T16:00:00.000Z',
                temperature=28.1,
                dewPoint=18.3,
                precipitation=0),
        ]
        for item in data:
            self.post_json(
                '/measurements',
                item
            )

    def test_get_exists(self):
        timestamp = '2015-09-01T16:20:00.000Z'
        response = self.get_json(
            '/measurements/{}'.format(timestamp)
        )
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(data['timestamp'], timestamp)
        self.assertEqual(data['temperature'], 27.5)
        self.assertEqual(data['dewPoint'], 17.1)
        self.assertEqual(data['precipitation'], 0)

    def test_get_non_exists(self):
        timestamp = '2015-09-01T16:50:00.000Z'
        response = self.get_json(
            '/measurements/{}'.format(timestamp)
        )
        self.assertEqual(response.status_code, 404)

    def test_get_by_day(self):
        timestamp = '2015-09-01'
        response = self.get_json(
            '/measurements/{}'.format(timestamp)
        )
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(data), 5)

    def test_get_by_day_empty(self):
        timestamp = '2015-09-03'
        response = self.get_json(
            '/measurements/{}'.format(timestamp)
        )
        self.assertEqual(response.status_code, 404)


class UpdateMesurementTestCase(JSONTestCase):
    def setUp(self):
        super(UpdateMesurementTestCase, self).setUp()
        data = [
            dict(
                timestamp='2015-09-01T16:00:00.000Z',
                temperature=27.1,
                dewPoint=16.7,
                precipitation=0),
            dict(
                timestamp='2015-09-01T16:10:00.000Z',
                temperature=27.3,
                dewPoint=16.9,
                precipitation=0),
        ]
        for item in data:
            self.post_json(
                '/measurements',
                item
            )

    def test_update(self):
        timestamp = '2015-09-01T16:00:00.000Z'
        item = dict(
            timestamp='2015-09-01T16:00:00.000Z',
            temperature=27.1,
            dewPoint=16.7,
            precipitation=15.2)
        response = self.put_json(
            '/measurements/{}'.format(timestamp),
            item
        )
        self.assertEqual(response.status_code, 204)

    def test_update_invalid(self):
        timestamp = '2015-09-01T16:00:00.000Z'
        item = dict(
            timestamp='2015-09-01T16:00:00.000Z',
            temperature="not num",
            dewPoint=16.7,
            precipitation=15.2)
        response = self.put_json(
            '/measurements/{}'.format(timestamp),
            item
        )
        self.assertEqual(response.status_code, 400)

    def test_update_mismatched(self):
        timestamp = '2015-09-01T16:00:00.000Z'
        item = dict(
            timestamp='2015-09-02T16:00:00.000Z',
            temperature=27.1,
            dewPoint=16.7,
            precipitation=15.2)
        response = self.put_json(
            '/measurements/{}'.format(timestamp),
            item
        )
        self.assertEqual(response.status_code, 409)

    def test_update_non_exits(self):
        timestamp = '2015-09-02T16:00:00.000Z'
        item = dict(
            timestamp='2015-09-02T16:00:00.000Z',
            temperature=27.1,
            dewPoint=16.7,
            precipitation=15.2)
        response = self.put_json(
            '/measurements/{}'.format(timestamp),
            item
        )
        self.assertEqual(response.status_code, 404)

    def test_partial_update(self):
        timestamp = '2015-09-01T16:00:00.000Z'
        item = dict(
            timestamp=timestamp,
            precipitation=12.3)
        response = self.patch_json(
            '/measurements/{}'.format(timestamp),
            item
        )
        self.assertEqual(response.status_code, 204)
        response = self.get_json(
            '/measurements/{}'.format(timestamp)
        )
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(data['timestamp'], timestamp)
        self.assertEqual(data['temperature'], 27.1)
        self.assertEqual(data['dewPoint'], 16.7)
        self.assertEqual(data['precipitation'], 12.3)

    def test_partial_update_invalid(self):
        timestamp = '2015-09-01T16:00:00.000Z'
        item = dict(
            timestamp=timestamp,
            precipitation="not num")
        response = self.patch_json(
            '/measurements/{}'.format(timestamp),
            item
        )
        self.assertEqual(response.status_code, 400)

    def test_partial_update_mismatched(self):
        timestamp = '2015-09-01T16:00:00.000Z'
        item = dict(
            timestamp='2015-09-02T16:00:00.000Z',
            precipitation=12.3)
        response = self.put_json(
            '/measurements/{}'.format(timestamp),
            item
        )
        self.assertEqual(response.status_code, 409)

    def test_partial_update_non_exits(self):
        timestamp = '2015-09-02T16:00:00.000Z'
        item = dict(
            timestamp='2015-09-02T16:00:00.000Z',
            precipitation=12.3)
        response = self.put_json(
            '/measurements/{}'.format(timestamp),
            item
        )
        self.assertEqual(response.status_code, 404)


class DeleteMesurementTestCase(JSONTestCase):
    def setUp(self):
        super(DeleteMesurementTestCase, self).setUp()
        data = [
            dict(
                timestamp='2015-09-01T16:00:00.000Z',
                temperature=27.1,
                dewPoint=16.7,
                precipitation=0),
            dict(
                timestamp='2015-09-01T16:10:00.000Z',
                temperature=27.3,
                dewPoint=16.9,
                precipitation=0),
        ]
        for item in data:
            self.post_json(
                '/measurements',
                item
            )

    def test_delete(self):
        timestamp = '2015-09-01T16:00:00.000Z'
        response = self.delete_json(
            '/measurements/{}'.format(timestamp),
        )
        self.assertEqual(response.status_code, 204)

    def test_delete_non_exists(self):
        timestamp = '2015-09-02T16:00:00.000Z'
        response = self.delete_json(
            '/measurements/{}'.format(timestamp),
        )
        self.assertEqual(response.status_code, 404)


class MesurementStatisticTestCase(JSONTestCase):
    def setUp(self):
        super(MesurementStatisticTestCase, self).setUp()
        data = [
            dict(
                timestamp='2015-09-01T16:00:00.000Z',
                temperature=27.1,
                dewPoint=16.9),
            dict(
                timestamp='2015-09-01T16:10:00.000Z',
                temperature=27.3,
                dewPoint=None),
            dict(
                timestamp='2015-09-01T16:20:00.000Z',
                temperature=27.5,
                dewPoint=17.1),
            dict(
                timestamp='2015-09-01T16:30:00.000Z',
                temperature=27.4,
                dewPoint=17.3),
            dict(
                timestamp='2015-09-01T16:40:00.000Z',
                temperature=27.2,
                dewPoint=None),
            dict(
                timestamp='2015-09-01T17:00:00.000Z',
                temperature=28.1,
                dewPoint=18.3),
        ]
        for item in data:
            self.post_json(
                '/measurements',
                item
            )

    def test_metrics(self):
        date_from = '2015-09-01T16:00:00.000Z'
        date_to = '2015-09-01T17:00:00.000Z'
        params = 'stat=min&stat=max&stat=average&metric=temperature&fromDateTime={}&toDateTime={}'.format(
            date_from, date_to
        )
        exp_data = [
            dict(
                metric='temperature',
                stat='max',
                value=27.5),
            dict(
                metric='temperature',
                stat='average',
                value=27.3),
            dict(
                metric='temperature',
                stat='min',
                value=27.1)]
        response = self.get_json('/stats?{}'.format(params))
        data = json.loads(response.data)
        self.assertEqual(data, exp_data)
        self.assertEqual(response.status_code, 200)

    def test_metrics_sparsely(self):
        date_from = '2015-09-01T16:00:00.000Z'
        date_to = '2015-09-01T17:00:00.000Z'
        params = 'stat=min&stat=max&stat=average&metric=dewPoint&fromDateTime={}&toDateTime={}'.format(
            date_from, date_to
        )
        exp_data = [
            dict(
                metric='dewPoint',
                stat='max',
                value=17.3),
            dict(
                metric='dewPoint',
                stat='average',
                value=17.1),
            dict(
                metric='dewPoint',
                stat='min',
                value=16.9)]
        response = self.get_json('/stats?{}'.format(params))
        data = json.loads(response.data)
        self.assertEqual(data, exp_data)
        self.assertEqual(response.status_code, 200)

    def test_metrics_non_exists(self):
        date_from = '2015-09-01T16:00:00.000Z'
        date_to = '2015-09-01T17:00:00.000Z'
        params = 'stat=min&stat=max&stat=average&metric=precipitation&fromDateTime={}&toDateTime={}'.format(
            date_from, date_to
        )
        response = self.get_json('/stats?{}'.format(params))
        data = json.loads(response.data)
        self.assertEqual(len(data), 0)
        self.assertEqual(response.status_code, 200)

    def test_metrics_multiple(self):
        date_from = '2015-09-01T16:00:00.000Z'
        date_to = '2015-09-01T17:00:00.000Z'
        params = 'stat=min&stat=max&stat=average&metric=temperature&metric=precipitation&metric=dewPoint&fromDateTime={}&toDateTime={}'.format(
            date_from, date_to
        )
        exp_data = [
            dict(
                metric='temperature',
                stat='max',
                value=27.5),
            dict(
                metric='temperature',
                stat='average',
                value=27.3),
            dict(
                metric='temperature',
                stat='min',
                value=27.1),
            dict(
                metric='dewPoint',
                stat='max',
                value=17.3),
            dict(
                metric='dewPoint',
                stat='average',
                value=17.1),
            dict(
                metric='dewPoint',
                stat='min',
                value=16.9)]
        response = self.get_json('/stats?{}'.format(params))
        data = json.loads(response.data)
        self.assertEqual(data, exp_data)
        self.assertEqual(response.status_code, 200)


if __name__ == '__main__':
    unittest.main()
