import sys

from settings import UNITS
from collections import OrderedDict


def inc_avg(n, cur_avg, new_value):
    """
    Helper function to calculate new average value if know prev average value and number of entries.
    prev_sum/n + K*new_value = (prev_sum+new_value)/(n+1)
    """
    return cur_avg + (new_value - cur_avg)/(n + 1)


class MemoryCache(object):
    """
    Simple memory cache incapsulates how data are stored.
    """

    def __init__(self, model_cls):
        self.data = OrderedDict()
        self.model_cls = model_cls

    def invalidate(self):
        self.data = OrderedDict()

    def exists(self, item_id):
        return item_id in self.data

    def create(self, raw_data):
        instance = self.model_cls(raw_data)
        self.data[instance.id] = instance
        return instance

    def get(self, item_id):
        return self.data[item_id]

    def update(self, item_id, raw_data, partial=False):
        item = self.get(item_id)
        item.partial_update(raw_data) if partial else item.update(raw_data)
        return item

    def delete(self, item_id):
        del self.data[item_id]

    def find(self, predicate):
        """
        Filter data by predicate.
        Complexity is O(n) where n - number of object in cache.
        """
        result = []
        for k, v in self.data.iteritems():
            if predicate(v):
                result.append(v)
        return result

    def aggregate(self, predicate, fields):
        """
        Aggregate stored data by max, min, average.
        Output format: [{<field_name>: {'max':<max_value>,  'min': <min_value>, 'average':{'v':<agv_value>,'num':<num_of_entries>}}}, ...]

        :param predicate: Filtering predicate.
        :param fields: List of fields to aggregate.
        :exception KeyError: In case if 'field' is not presemted in stored object.
        """
        result = {}
        for k, v in self.data.iteritems():
            if predicate(v):
                for field in fields:
                    if v[field] is None:
                        continue
                    cur_stat = result.get(field, {
                        'average': {'v': 0, 'num': 0},
                        'max': sys.float_info.min,
                        'min': sys.float_info.max,
                    })
                    cur_stat['max'] = max(v[field], cur_stat['max'])
                    cur_stat['min'] = min(v[field], cur_stat['min'])
                    cur_stat['average']['v'] = inc_avg(
                        cur_stat['average']['num'], cur_stat['average']['v'], v[field])
                    cur_stat['average']['num'] = cur_stat['average']['num'] + 1
                    result[field] = cur_stat
        return result


class Metric(object):

    def __init__(self, name, value):
        self.name = name
        self.value = value

    def __repr__(self):
        return 'name:{} value:{}'.format(self.name, self.value)


class MetricStat(object):

    def __init__(self, metric, stat, value):
        self.metric = metric
        self.stat = stat
        self.value = value


class Measurement(object):
    """
    Model class to store single measurement.
    Has static variable 'objects' to store reference to storage instance
    """
    objects = None

    def __init__(self, raw_data):
        self.id = raw_data['timestamp']
        self.timestamp = self.id
        self.datetime = raw_data['datetime']
        self.update(raw_data)

    def __repr__(self):
        return 'Measurement metrics:{}'.format(self.metrics)

    def __getitem__(self, key):
        return self.metrics[key].value

    def update(self, raw_data):
        metrics = [Metric(unit, raw_data.get(unit)) for unit in UNITS]
        self.metrics = {m.name: m for m in metrics}

    def partial_update(self, raw_data):
        for unit in UNITS:
            v = raw_data.get(unit)
            if v:
                self.metrics[unit].value = v

Measurement.objects = MemoryCache(Measurement)
