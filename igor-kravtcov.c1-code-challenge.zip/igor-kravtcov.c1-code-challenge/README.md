# Code challenge v1.3

A list of available metrics is in settings.py.

## How to run

 - Install virtualenv and activate it.
 - Install dependecies and start the server


```sh
$ pip install -r requirements.txt
$ python app.py
```

## Tests

Run tests by command

```sh
$ python tests.py
```